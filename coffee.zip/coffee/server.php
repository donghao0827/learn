<?php
  require('queryDb.php');
  echo getProducts()[1]['name'];
?>